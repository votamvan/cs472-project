# CS472 Final Project - Movie Shop
## To run the project just run "mvn package && sh target/bin/webapp" in terminal

Professor: Rakesh Shrestha

Team:

* Duy Trung Do - 986891
* Tam Van Vo - 610746   
   
