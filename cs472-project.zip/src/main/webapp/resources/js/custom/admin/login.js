(function ($){
    "use strict";

    $(document).ready(function(){

        /*-------------------
		Error Message
        --------------------- */
        var button = $('button.site-btn');        
        $(button).next().css('color','red').css('display','block').css('margin','20px');
        
    });
})(jQuery);